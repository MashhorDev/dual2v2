<?php
// auth/handler.php — POST handler for login & signup
require_once __DIR__ . '/../backend/config.php';
require_once __DIR__ . '/../backend/auth.php';

header('Content-Type: application/json; charset=utf-8');

$action = trim($_POST['action'] ?? $_GET['action'] ?? '');

if ($action === 'signup') {
    $result = signup(
        $_POST['username'] ?? '',
        $_POST['email']    ?? '',
        $_POST['password'] ?? ''
    );
    echo json_encode($result);
    exit;
}

if ($action === 'login') {
    $result = login(
        $_POST['identifier'] ?? '',
        $_POST['password']   ?? ''
    );
    echo json_encode($result);
    exit;
}

if ($action === 'logout') {
    logout();
    echo json_encode(['ok'=>true]);
    exit;
}

http_response_code(400);
echo json_encode(['ok'=>false,'error'=>'Unknown action']);
