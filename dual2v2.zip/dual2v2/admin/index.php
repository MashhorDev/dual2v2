<?php
require_once __DIR__ . '/../backend/config.php';
require_once __DIR__ . '/../backend/auth.php';
require_admin();

$db = auth_db();

// ── Handle approve / deny ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $req_id  = (int)($_POST['req_id']  ?? 0);
    $act     = $_POST['act'] ?? '';
    $admin   = current_user();

    if ($req_id && in_array($act, ['approve','deny'], true)) {
        // Load the request
        $rq = $db->prepare('SELECT * FROM claim_requests WHERE id=? LIMIT 1');
        $rq->execute([$req_id]);
        $req = $rq->fetch();

        if ($req && $req['status'] === 'pending') {
            if ($act === 'approve') {
                // Check player not already claimed by someone else
                $pl = $db->prepare('SELECT claimed_by FROM players WHERE id=? LIMIT 1');
                $pl->execute([$req['player_id']]);
                $player = $pl->fetch();

                if (empty($player['claimed_by'])) {
                    // Grant claim
                    $db->prepare('UPDATE players SET claimed_by=?,claimed_at=NOW() WHERE id=?')
                       ->execute([$req['user_id'], $req['player_id']]);
                    // Update request
                    $db->prepare('UPDATE claim_requests SET status="approved",resolved_at=NOW(),resolved_by=? WHERE id=?')
                       ->execute([$admin['id'], $req_id]);
                    // Deny all OTHER pending requests for this player
                    $db->prepare('UPDATE claim_requests SET status="denied",resolved_at=NOW(),resolved_by=? WHERE player_id=? AND id!=? AND status="pending"')
                       ->execute([$admin['id'], $req['player_id'], $req_id]);
                }
            } else {
                $db->prepare('UPDATE claim_requests SET status="denied",resolved_at=NOW(),resolved_by=? WHERE id=?')
                   ->execute([$admin['id'], $req_id]);
            }
        }
        header('Location: '.SITE_URL.'/admin/');
        exit;
    }
}

// ── Load pending requests ──────────────────────────────────
$pending = $db->query("
    SELECT cr.id, cr.requested_at,
           u.username, u.email,
           p.riot_name, p.riot_tag, p.region, p.vanity_slug
    FROM claim_requests cr
    JOIN users   u ON u.id = cr.user_id
    JOIN players p ON p.id = cr.player_id
    WHERE cr.status = 'pending'
    ORDER BY cr.requested_at ASC
")->fetchAll();

$resolved = $db->query("
    SELECT cr.id, cr.status, cr.requested_at, cr.resolved_at,
           u.username,
           p.riot_name, p.riot_tag,
           au.username AS resolved_by_name
    FROM claim_requests cr
    JOIN users   u  ON u.id  = cr.user_id
    JOIN players p  ON p.id  = cr.player_id
    LEFT JOIN users au ON au.id = cr.resolved_by
    WHERE cr.status != 'pending'
    ORDER BY cr.resolved_at DESC
    LIMIT 50
")->fetchAll();

$totalUsers   = (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
$totalPlayers = (int)$db->query('SELECT COUNT(*) FROM players')->fetchColumn();
$totalClaimed = (int)$db->query('SELECT COUNT(*) FROM players WHERE claimed_by IS NOT NULL')->fetchColumn();

$userClaims = $db->query("
    SELECT u.id, u.username, u.email, u.created_at,
           COUNT(p.id) AS approved_claims,
           (SELECT COUNT(*) FROM claim_requests cr WHERE cr.user_id=u.id AND cr.status='pending') AS pending_claims
    FROM users u
    LEFT JOIN players p ON p.claimed_by = u.id
    GROUP BY u.id
    ORDER BY approved_claims DESC, u.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>DUAL // Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0f1014;color:#c8cfe0;font-family:'Space Mono',monospace;min-height:100vh}
body::before{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(255,70,85,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,70,85,.03) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none}
header{position:relative;z-index:10;padding:20px 40px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #1e2130}
.logo{font-family:'Bebas Neue',sans-serif;font-size:1.8rem;letter-spacing:4px;color:#fff}
.logo span{color:#ff4655}
.logo small{font-family:'Space Mono',monospace;font-size:.55rem;letter-spacing:3px;color:#ff4655;margin-left:8px;vertical-align:middle;background:rgba(255,70,85,.15);padding:3px 8px;border:1px solid rgba(255,70,85,.3)}
nav a{color:#3a3f56;text-decoration:none;font-size:.65rem;letter-spacing:2px;text-transform:uppercase;margin-left:20px;transition:color .2s}
nav a:hover{color:#ff4655}
main{max-width:1100px;margin:0 auto;padding:40px 24px}
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:40px}
.stat-box{background:#14161c;border:1px solid #1e2130;padding:24px;border-top:3px solid #ff4655}
.stat-box .n{font-family:'Bebas Neue',sans-serif;font-size:2.4rem;color:#fff}
.stat-box .l{font-size:.58rem;letter-spacing:3px;text-transform:uppercase;color:#3a3f56;margin-top:4px}
.section-title{font-family:'Bebas Neue',sans-serif;font-size:1.3rem;letter-spacing:4px;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:10px}
.section-title::after{content:'';flex:1;height:1px;background:#1e2130}
.badge{display:inline-block;font-size:.55rem;letter-spacing:2px;background:#ff4655;color:#fff;padding:2px 8px;margin-left:8px;clip-path:polygon(4px 0%,100% 0%,calc(100% - 4px) 100%,0 100%)}
.badge.green{background:#15ff80;color:#0f1014}
table{width:100%;border-collapse:collapse;margin-bottom:40px}
th{font-size:.58rem;letter-spacing:2px;text-transform:uppercase;color:#3a3f56;text-align:left;padding:10px 14px;border-bottom:1px solid #1e2130}
td{padding:14px;border-bottom:1px solid rgba(30,33,48,.5);font-size:.73rem;vertical-align:middle}
tr:hover td{background:rgba(255,70,85,.03)}
.player-name{color:#fff;font-weight:700}
.username{color:#00d4ff}
.time{color:#3a3f56;font-size:.62rem}
.btn{border:none;cursor:pointer;font-family:'Bebas Neue',sans-serif;font-size:.9rem;letter-spacing:2px;padding:8px 18px;clip-path:polygon(4px 0%,100% 0%,calc(100% - 4px) 100%,0 100%);transition:opacity .2s}
.btn:hover{opacity:.85}
.btn-approve{background:#15ff80;color:#0f1014}
.btn-deny{background:#ff4655;color:#fff}
.status-approved{color:#15ff80;font-size:.62rem;letter-spacing:2px}
.status-denied{color:#ff4655;font-size:.62rem;letter-spacing:2px}
.empty{color:#3a3f56;font-size:.72rem;letter-spacing:2px;padding:24px;border:1px dashed #1e2130;text-align:center}
.tag-muted{color:#3a3f56}
.slug-link{color:#f5c842;font-size:.65rem;text-decoration:none}
.slug-link:hover{color:#fff}
.claim-count-badge{font-family:'Bebas Neue',sans-serif;font-size:1rem;padding:2px 10px;display:inline-block}
.claim-count-badge.has-claim{color:#ff4655;background:rgba(255,70,85,.1);border:1px solid rgba(255,70,85,.3)}
.claim-count-badge.no-claim{color:#3a3f56;background:rgba(58,63,86,.1);border:1px solid #1e2130}
.pending-badge{font-size:.58rem;letter-spacing:2px;color:#f5c842;background:rgba(245,200,66,.1);border:1px solid rgba(245,200,66,.3);padding:2px 8px;margin-left:6px}
</style>
</head>
<body>
<header>
  <div class="logo">DUAL<span>//</span>2V2 <small>ADMIN</small></div>
  <nav>
    <a href="<?=SITE_URL?>/">← Back to Site</a>
    <a href="<?=SITE_URL?>/auth/handler.php?action=logout" onclick="fetch('<?=SITE_URL?>/auth/handler.php',{method:'POST',body:new URLSearchParams({action:'logout'})}).then(()=>location.href='<?=SITE_URL?>/');return false">Logout</a>
  </nav>
</header>
<main>

  <div class="stats-row">
    <div class="stat-box"><div class="n"><?=$totalUsers?></div><div class="l">Registered Users</div></div>
    <div class="stat-box"><div class="n"><?=$totalPlayers?></div><div class="l">Tracked Players</div></div>
    <div class="stat-box"><div class="n"><?=$totalClaimed?></div><div class="l">Claimed Profiles</div></div>
  </div>

  <div class="section-title">
    Pending Claim Requests
    <?php if (count($pending)): ?>
      <span class="badge"><?=count($pending)?></span>
    <?php endif; ?>
  </div>

  <?php if (!$pending): ?>
    <div class="empty">NO PENDING REQUESTS</div>
  <?php else: ?>
  <table>
    <thead>
      <tr>
        <th>Requested</th>
        <th>User</th>
        <th>Wants to Claim</th>
        <th>Profile Link</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($pending as $r): ?>
      <tr>
        <td class="time"><?=htmlspecialchars($r['requested_at'])?></td>
        <td><span class="username"><?=htmlspecialchars($r['username'])?></span></td>
        <td class="player-name">
          <?=htmlspecialchars($r['riot_name'])?><span class="tag-muted">#<?=htmlspecialchars($r['riot_tag'])?></span>
          <div style="font-size:.58rem;color:#3a3f56;margin-top:2px"><?=strtoupper($r['region'])?></div>
        </td>
        <td>
          <?php if ($r['vanity_slug']): ?>
            <a class="slug-link" href="<?=SITE_URL?>/@<?=htmlspecialchars($r['vanity_slug'])?>" target="_blank">
              @<?=htmlspecialchars($r['vanity_slug'])?>
            </a>
          <?php else: ?><span class="tag-muted">—</span><?php endif; ?>
        </td>
        <td>
          <form method="POST" style="display:inline">
            <input type="hidden" name="req_id" value="<?=$r['id']?>">
            <input type="hidden" name="act" value="approve">
            <button class="btn btn-approve" type="submit">APPROVE</button>
          </form>
          &nbsp;
          <form method="POST" style="display:inline">
            <input type="hidden" name="req_id" value="<?=$r['id']?>">
            <input type="hidden" name="act" value="deny">
            <button class="btn btn-deny" type="submit">DENY</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <div class="section-title">Recent Resolved</div>
  <?php if (!$resolved): ?>
    <div class="empty">NO RESOLVED REQUESTS YET</div>
  <?php else: ?>
  <table>
    <thead>
      <tr><th>Status</th><th>User</th><th>Profile</th><th>Resolved By</th><th>Resolved At</th></tr>
    </thead>
    <tbody>
    <?php foreach ($resolved as $r): ?>
      <tr>
        <td><span class="status-<?=$r['status']?>"><?=strtoupper($r['status'])?></span></td>
        <td><span class="username"><?=htmlspecialchars($r['username'])?></span></td>
        <td class="player-name"><?=htmlspecialchars($r['riot_name'])?><span class="tag-muted">#<?=htmlspecialchars($r['riot_tag'])?></span></td>
        <td style="color:#3a3f56"><?=htmlspecialchars($r['resolved_by_name']??'—')?></td>
        <td class="time"><?=htmlspecialchars($r['resolved_at']??'—')?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <div class="section-title">Users &amp; Claim Limits</div>
  <p style="font-size:.62rem;color:#3a3f56;letter-spacing:1px;margin-bottom:16px">Each user may hold a maximum of <strong style="color:#ff4655">1 approved profile</strong>. Users with 1+ claims cannot submit new requests.</p>
  <?php if (!$userClaims): ?>
    <div class="empty">NO USERS YET</div>
  <?php else: ?>
  <table>
    <thead>
      <tr>
        <th>User</th>
        <th>Email</th>
        <th>Registered</th>
        <th>Approved Claims</th>
        <th>Claimed Profile</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($userClaims as $u):
      // Get the claimed player slug if any
      $cp = null;
      if ((int)$u['approved_claims'] > 0) {
          $cpSt = $db->prepare('SELECT riot_name, riot_tag, vanity_slug FROM players WHERE claimed_by=? LIMIT 1');
          $cpSt->execute([$u['id']]);
          $cp = $cpSt->fetch();
      }
    ?>
      <tr>
        <td><span class="username"><?=htmlspecialchars($u['username'])?></span>
          <?php if ($u['pending_claims'] > 0): ?>
            <span class="pending-badge">⏳ <?=(int)$u['pending_claims']?> PENDING</span>
          <?php endif; ?>
        </td>
        <td style="color:#3a3f56;font-size:.65rem"><?=htmlspecialchars($u['email'])?></td>
        <td class="time"><?=htmlspecialchars(date('M j, Y', strtotime($u['created_at'])))?></td>
        <td>
          <span class="claim-count-badge <?=(int)$u['approved_claims']>0?'has-claim':'no-claim'?>">
            <?=(int)$u['approved_claims']?> / 1
          </span>
        </td>
        <td>
          <?php if ($cp): ?>
            <span class="player-name"><?=htmlspecialchars($cp['riot_name'])?><span class="tag-muted">#<?=htmlspecialchars($cp['riot_tag'])?></span></span>
            <?php if ($cp['vanity_slug']): ?>
              &nbsp;<a class="slug-link" href="<?=SITE_URL?>/@<?=htmlspecialchars($cp['vanity_slug'])?>" target="_blank">@<?=htmlspecialchars($cp['vanity_slug'])?></a>
            <?php endif; ?>
          <?php else: ?>
            <span class="tag-muted">—</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

</main>
</body>
</html>
