-- ============================================================
--  DUAL // 2v2 — Full Schema
--  Includes: users, players, matches, claim_requests
-- ============================================================

CREATE DATABASE IF NOT EXISTS dual2v2 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dual2v2;

CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(32)  NOT NULL UNIQUE,
    email         VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_admin      TINYINT(1)   NOT NULL DEFAULT 0,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS players (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    puuid          VARCHAR(80)  NOT NULL UNIQUE,
    riot_name      VARCHAR(64)  NOT NULL,
    riot_tag       VARCHAR(12)  NOT NULL,
    region         VARCHAR(10)  NOT NULL DEFAULT 'na',
    card_url       TEXT,
    total_cp       INT          NOT NULL DEFAULT 0,
    cp_in_tier     SMALLINT     NOT NULL DEFAULT 0,
    tier           TINYINT      NOT NULL DEFAULT 0,
    wins           SMALLINT     NOT NULL DEFAULT 0,
    losses         SMALLINT     NOT NULL DEFAULT 0,
    win_streak     TINYINT      NOT NULL DEFAULT 0,
    placement_done TINYINT(1)   NOT NULL DEFAULT 0,
    last_sync      DATETIME,
    claimed_by     INT UNSIGNED NULL,
    claimed_at     DATETIME     NULL,
    vanity_slug    VARCHAR(80)  NULL UNIQUE,
    nickname       VARCHAR(40)  NULL,
    country_flag   VARCHAR(8)   NULL,
    hide_rank      TINYINT(1)   NOT NULL DEFAULT 0,
    hide_stats     TINYINT(1)   NOT NULL DEFAULT 0,
    created_at     DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_total_cp (total_cp DESC),
    INDEX idx_region   (region),
    INDEX idx_claimed  (claimed_by),
    FOREIGN KEY (claimed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS matches (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    player_id     INT UNSIGNED NOT NULL,
    match_id      VARCHAR(80)  NOT NULL,
    map_name      VARCHAR(40),
    queue_id      VARCHAR(60),
    partner_puuid VARCHAR(80),
    partner_name  VARCHAR(80),
    won           TINYINT(1)   NOT NULL DEFAULT 0,
    kills         TINYINT      NOT NULL DEFAULT 0,
    deaths        TINYINT      NOT NULL DEFAULT 0,
    assists       TINYINT      NOT NULL DEFAULT 0,
    headshots     SMALLINT     NOT NULL DEFAULT 0,
    bodyshots     SMALLINT     NOT NULL DEFAULT 0,
    legshots      SMALLINT     NOT NULL DEFAULT 0,
    rounds_won    TINYINT      NOT NULL DEFAULT 0,
    rounds_lost   TINYINT      NOT NULL DEFAULT 0,
    cp_delta      SMALLINT     NOT NULL DEFAULT 0,
    kda_ratio     DECIMAL(5,2) NOT NULL DEFAULT 0,
    played_at     DATETIME,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_player_match (player_id, match_id),
    INDEX idx_player (player_id),
    INDEX idx_played (played_at DESC),
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS claim_requests (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    player_id    INT UNSIGNED NOT NULL,
    status       ENUM('pending','approved','denied') NOT NULL DEFAULT 'pending',
    requested_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
    resolved_at  DATETIME     NULL,
    resolved_by  INT UNSIGNED NULL,
    UNIQUE KEY uq_user_player (user_id, player_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB;
