<?php
// ============================================================
//  DUAL // 2v2 — auth.php
//  Session management, login, signup, logout
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_name('dual2v2_sess');
    session_set_cookie_params([
        'lifetime' => 86400 * 30,
        'path'     => '/',
        'secure'   => false,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/config.php';

// ── DB singleton ───────────────────────────────────────────
function auth_db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO(
        'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
    return $pdo;
}

// ── Current user ───────────────────────────────────────────
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    static $cache = null;
    if ($cache) return $cache;
    $st = auth_db()->prepare('SELECT id,username,email,is_admin FROM users WHERE id=? LIMIT 1');
    $st->execute([$_SESSION['user_id']]);
    $cache = $st->fetch() ?: null;
    return $cache;
}

function is_logged_in(): bool { return current_user() !== null; }
function is_admin(): bool     { $u = current_user(); return $u && (int)$u['is_admin'] === 1; }

function require_login(string $redirect = '/dual2v2/login.php'): void {
    if (!is_logged_in()) {
        header('Location: '.SITE_URL.'/login.php?next='.urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}
function require_admin(): void {
    require_login();
    if (!is_admin()) { http_response_code(403); exit('Forbidden'); }
}

// ── Signup ─────────────────────────────────────────────────
// Returns ['ok'=>true] or ['ok'=>false,'error'=>'...']
function signup(string $username, string $email, string $password): array {
    $username = trim($username);
    $email    = trim(strtolower($email));

    if (strlen($username) < 3 || strlen($username) > 32)
        return ['ok'=>false,'error'=>'Username must be 3-32 characters'];
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username))
        return ['ok'=>false,'error'=>'Username can only contain letters, numbers, and underscores'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        return ['ok'=>false,'error'=>'Invalid email address'];
    if (strlen($password) < 6)
        return ['ok'=>false,'error'=>'Password must be at least 6 characters'];

    $db = auth_db();

    $chk = $db->prepare('SELECT id FROM users WHERE username=? OR email=? LIMIT 1');
    $chk->execute([$username, $email]);
    if ($chk->fetch()) return ['ok'=>false,'error'=>'Username or email already taken'];

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $db->prepare('INSERT INTO users (username,email,password_hash) VALUES (?,?,?)')
       ->execute([$username, $email, $hash]);

    $uid = (int)$db->lastInsertId();
    $_SESSION['user_id'] = $uid;
    return ['ok'=>true,'user_id'=>$uid];
}

// ── Login ──────────────────────────────────────────────────
function login(string $identifier, string $password): array {
    $identifier = trim($identifier);
    $db  = auth_db();
    $st  = $db->prepare('SELECT * FROM users WHERE username=? OR email=? LIMIT 1');
    $st->execute([$identifier, strtolower($identifier)]);
    $user = $st->fetch();

    if (!$user || !password_verify($password, $user['password_hash']))
        return ['ok'=>false,'error'=>'Invalid username/email or password'];

    $_SESSION['user_id'] = (int)$user['id'];
    session_regenerate_id(true);
    return ['ok'=>true,'user_id'=>(int)$user['id'],'is_admin'=>(int)$user['is_admin']];
}

// ── Logout ─────────────────────────────────────────────────
function logout(): void {
    $_SESSION = [];
    session_destroy();
}

// ── Claim helpers ──────────────────────────────────────────
// Returns state for a given user + player combo
// 'none' | 'pending' | 'approved' | 'denied' | 'claimed_by_other'
function claim_state(int $user_id, int $player_id): string {
    $db = auth_db();

    // Check if player is already claimed by someone
    $pl = $db->prepare('SELECT claimed_by FROM players WHERE id=? LIMIT 1');
    $pl->execute([$player_id]);
    $row = $pl->fetch();
    if (!$row) return 'none';
    if (!empty($row['claimed_by'])) {
        return (int)$row['claimed_by'] === $user_id ? 'approved' : 'claimed_by_other';
    }

    // Check for a request
    $rq = $db->prepare('SELECT status FROM claim_requests WHERE user_id=? AND player_id=? LIMIT 1');
    $rq->execute([$user_id, $player_id]);
    $req = $rq->fetch();
    return $req ? $req['status'] : 'none';
}

// Submit a claim request (one per user per player)
function submit_claim(int $user_id, int $player_id): array {
    // Enforce max 1 approved claim per user
    $owned = auth_db()->prepare('SELECT COUNT(*) FROM players WHERE claimed_by=?');
    $owned->execute([$user_id]);
    if ((int)$owned->fetchColumn() > 0)
        return ['ok'=>false,'error'=>'You already have a claimed profile. Each account can only claim 1 profile.'];

    $state = claim_state($user_id, $player_id);
    if ($state === 'approved')         return ['ok'=>false,'error'=>'You already own this profile'];
    if ($state === 'claimed_by_other') return ['ok'=>false,'error'=>'Profile already claimed'];
    if ($state === 'pending')          return ['ok'=>false,'error'=>'Request already pending'];

    try {
        auth_db()->prepare('INSERT IGNORE INTO claim_requests (user_id,player_id) VALUES (?,?)')
                 ->execute([$user_id, $player_id]);
        return ['ok'=>true];
    } catch (Throwable $e) {
        return ['ok'=>false,'error'=>'DB error: '.$e->getMessage()];
    }
}
