<?php
// ============================================================
//  DUAL // 2v2 — api/index.php
//  Actions: ping, search, leaderboard, claim, profile_update,
//           me, logout, vanity
// ============================================================

require_once __DIR__ . '/../backend/config.php';
require_once __DIR__ . '/../backend/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
ini_set('display_errors', '0');

function respond($arr, $code = 200) {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function gq($k, $d = '') { return isset($_GET[$k])  ? trim((string)$_GET[$k])  : $d; }
function pp($k, $d = '') { return isset($_POST[$k]) ? trim((string)$_POST[$k]) : $d; }

function pick($arr, $path, $default = null) {
    $cur = $arr;
    foreach (explode('.', $path) as $k) {
        if (!is_array($cur) || !array_key_exists($k, $cur)) return $default;
        $cur = $cur[$k];
    }
    return $cur;
}
function hget($url, $key) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER => ['Authorization: '.$key,'Accept: application/json'],
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_USERAGENT => 'dual2v2/1.0',
    ]);
    $body = curl_exec($ch); $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($body === false) throw new Exception("cURL: $err");
    $json = json_decode($body, true);
    if (!is_array($json)) throw new Exception("Non-JSON (HTTP $code): ".substr($body,0,300));
    return [$code, $json];
}
function ensure_tables($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(32) NOT NULL UNIQUE, email VARCHAR(120) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL, is_admin TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS players (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        puuid VARCHAR(80) NOT NULL UNIQUE, riot_name VARCHAR(64) NOT NULL,
        riot_tag VARCHAR(12) NOT NULL, region VARCHAR(10) NOT NULL DEFAULT 'na',
        card_url TEXT, total_cp INT NOT NULL DEFAULT 0, cp_in_tier SMALLINT NOT NULL DEFAULT 0,
        tier TINYINT NOT NULL DEFAULT 0, wins SMALLINT NOT NULL DEFAULT 0,
        losses SMALLINT NOT NULL DEFAULT 0, win_streak TINYINT NOT NULL DEFAULT 0,
        placement_done TINYINT(1) NOT NULL DEFAULT 0, last_sync DATETIME,
        claimed_by INT UNSIGNED NULL, claimed_at DATETIME NULL,
        vanity_slug VARCHAR(80) NULL UNIQUE,
        nickname VARCHAR(40) NULL, country_flag VARCHAR(8) NULL,
        hide_rank TINYINT(1) NOT NULL DEFAULT 0, hide_stats TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_cp (total_cp), INDEX idx_region (region),
        FOREIGN KEY (claimed_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS matches (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        player_id INT UNSIGNED NOT NULL, match_id VARCHAR(80) NOT NULL,
        map_name VARCHAR(40), queue_id VARCHAR(60),
        partner_puuid VARCHAR(80), partner_name VARCHAR(80),
        won TINYINT(1) NOT NULL DEFAULT 0, kills TINYINT NOT NULL DEFAULT 0,
        deaths TINYINT NOT NULL DEFAULT 0, assists TINYINT NOT NULL DEFAULT 0,
        headshots SMALLINT NOT NULL DEFAULT 0, bodyshots SMALLINT NOT NULL DEFAULT 0,
        legshots SMALLINT NOT NULL DEFAULT 0, rounds_won TINYINT NOT NULL DEFAULT 0,
        rounds_lost TINYINT NOT NULL DEFAULT 0, cp_delta SMALLINT NOT NULL DEFAULT 0,
        kda_ratio DECIMAL(5,2) NOT NULL DEFAULT 0, played_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_pm (player_id, match_id), INDEX idx_pl (player_id),
        INDEX idx_pa (played_at),
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS claim_requests (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL, player_id INT UNSIGNED NOT NULL,
        status ENUM('pending','approved','denied') NOT NULL DEFAULT 'pending',
        requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL, resolved_by INT UNSIGNED NULL,
        UNIQUE KEY uq_up (user_id, player_id), INDEX idx_status (status),
        FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── Boot ───────────────────────────────────────────────────
$action = gq('action');
if ($action === 'ping') respond(['ok'=>true,'msg'=>'api online']);

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (Throwable $e) { respond(['ok'=>false,'error'=>'DB: '.$e->getMessage()],500); }
try { ensure_tables($pdo); } catch (Throwable $e) { respond(['ok'=>false,'error'=>'Tables: '.$e->getMessage()],500); }

// ── me — return current logged-in user info ────────────────
if ($action === 'me') {
    $u = current_user();
    if (!$u) respond(['ok'=>true,'logged_in'=>false]);
    // Find their claimed player if any
    $cp = $pdo->prepare('SELECT id,riot_name,riot_tag,vanity_slug,nickname,country_flag,hide_rank,hide_stats FROM players WHERE claimed_by=? LIMIT 1');
    $cp->execute([$u['id']]);
    $claimedPlayer = $cp->fetch() ?: null;
    respond(['ok'=>true,'logged_in'=>true,'user'=>$u,'claimed_player'=>$claimedPlayer]);
}

// ── logout ─────────────────────────────────────────────────
if ($action === 'logout') {
    logout();
    respond(['ok'=>true]);
}

// ── vanity — load profile by slug ─────────────────────────
if ($action === 'vanity') {
    $slug = gq('slug');
    if (!$slug) respond(['ok'=>false,'error'=>'slug required']);
    $st = $pdo->prepare('SELECT id,riot_name,riot_tag,region FROM players WHERE vanity_slug=? LIMIT 1');
    $st->execute([$slug]);
    $row = $st->fetch();
    if (!$row) respond(['ok'=>false,'error'=>'Profile not found']);
    respond(['ok'=>true,'name'=>$row['riot_name'],'tag'=>$row['riot_tag'],'region'=>$row['region']]);
}

// ── leaderboard ────────────────────────────────────────────
if ($action === 'leaderboard') {
    $region = gq('region','all');
    $limit  = max(1,min(200,(int)gq('limit','50')));
    try {
        if ($region === 'all') {
            $st = $pdo->prepare("SELECT riot_name,riot_tag,region,total_cp,cp_in_tier,tier,wins,losses,win_streak,
                nickname,country_flag,hide_rank,vanity_slug
                FROM players WHERE placement_done=1 ORDER BY total_cp DESC LIMIT $limit");
            $st->execute();
        } else {
            $st = $pdo->prepare("SELECT riot_name,riot_tag,region,total_cp,cp_in_tier,tier,wins,losses,win_streak,
                nickname,country_flag,hide_rank,vanity_slug
                FROM players WHERE placement_done=1 AND region=? ORDER BY total_cp DESC LIMIT $limit");
            $st->execute([$region]);
        }
        respond(['ok'=>true,'leaderboard'=>$st->fetchAll()]);
    } catch (Throwable $e) { respond(['ok'=>false,'error'=>'Leaderboard: '.$e->getMessage()],500); }
}

// ── claim — submit a claim request ────────────────────────
if ($action === 'claim') {
    if (!is_logged_in()) respond(['ok'=>false,'error'=>'Login required to claim a profile'],401);
    $player_id = (int)gq('player_id');
    if (!$player_id) respond(['ok'=>false,'error'=>'player_id required']);
    $u = current_user();
    $result = submit_claim((int)$u['id'], $player_id);
    respond($result);
}

// ── profile_update — update nickname/flag/visibility ──────
if ($action === 'profile_update') {
    if (!is_logged_in()) respond(['ok'=>false,'error'=>'Login required'],401);
    $u = current_user();

    // Find player claimed by this user
    $st = $pdo->prepare('SELECT id FROM players WHERE claimed_by=? LIMIT 1');
    $st->execute([$u['id']]);
    $player = $st->fetch();
    if (!$player) respond(['ok'=>false,'error'=>'You have no claimed profile']);

    $nickname    = substr(pp('nickname'), 0, 40);
    $flag        = substr(pp('country_flag'), 0, 8);  // accept any emoji, no regex
    $hide_rank   = pp('hide_rank')  === '1' ? 1 : 0;
    $hide_stats  = pp('hide_stats') === '1' ? 1 : 0;

    $pdo->prepare('UPDATE players SET nickname=?,country_flag=?,hide_rank=?,hide_stats=? WHERE id=?')
        ->execute([$nickname ?: null, $flag ?: null, $hide_rank, $hide_stats, $player['id']]);

    respond(['ok'=>true]);
}

// ── search + sync ──────────────────────────────────────────
if ($action !== 'search') respond(['ok'=>false,'error'=>'Unknown action'],400);

$name   = gq('name');
$tag    = gq('tag');
$region = strtolower(gq('region','na'));
if (!in_array($region,['na','eu','ap','kr','br','latam'],true)) $region = 'na';
if (!$name || !$tag) respond(['ok'=>false,'error'=>'name and tag required'],400);

$debug = gq('debug') === '1';

// 1. Account lookup
try {
    [$accCode,$accJson] = hget(
        'https://api.henrikdev.xyz/valorant/v1/account/'.rawurlencode($name).'/'.rawurlencode($tag),
        HENRIK_API_KEY
    );
} catch (Throwable $e) { respond(['ok'=>false,'error'=>'Account lookup: '.$e->getMessage()]); }

if ($accCode===404||empty($accJson['data']['puuid']))
    respond(['ok'=>false,'error'=>'Player not found.']);
if ($accCode===403) respond(['ok'=>false,'error'=>'Henrik API key invalid (403).']);
if ($accCode!==200) respond(['ok'=>false,'error'=>'Henrik account API: HTTP '.$accCode]);

$acc     = $accJson['data'];
$puuid   = (string)($acc['puuid']??'');
$cardUid = (string)($acc['card']??'');
$cardUrl = $cardUid ? "https://media.valorant-api.com/playercards/{$cardUid}/smallart.png" : '';
if (!empty($acc['region'])) $region = strtolower($acc['region']);

// 2. Upsert player
try {
    $st = $pdo->prepare('SELECT * FROM players WHERE puuid=? LIMIT 1');
    $st->execute([$puuid]);
    $row = $st->fetch();
    if (!$row) {
        $slug = strtolower($name).'-'.strtolower($tag);
        $slug = preg_replace('/[^a-z0-9\-]/','',$slug);
        // Ensure slug uniqueness
        $base = $slug; $i = 1;
        while (true) {
            $chk = $pdo->prepare('SELECT id FROM players WHERE vanity_slug=? LIMIT 1');
            $chk->execute([$slug]);
            if (!$chk->fetch()) break;
            $slug = $base.'-'.(++$i);
        }
        $pdo->prepare('INSERT INTO players (puuid,riot_name,riot_tag,region,card_url,vanity_slug) VALUES (?,?,?,?,?,?)')
            ->execute([$puuid,$name,$tag,$region,$cardUrl,$slug]);
        $playerId = (int)$pdo->lastInsertId();
        $st->execute([$puuid]);
        $row = $st->fetch();
    } else {
        $playerId = (int)$row['id'];
        $pdo->prepare('UPDATE players SET riot_name=?,riot_tag=?,region=?,card_url=? WHERE id=?')
            ->execute([$name,$tag,$region,$cardUrl,$playerId]);
    }
} catch (Throwable $e) { respond(['ok'=>false,'error'=>'DB upsert: '.$e->getMessage()]); }

$total_cp   = (int)$row['total_cp'];
$wins       = (int)$row['wins'];
$losses     = (int)$row['losses'];
$win_streak = (int)$row['win_streak'];
$placement  = (int)$row['placement_done'];

// 3. Fetch matches — Henrik v3
try {
    $mUrl = 'https://api.henrikdev.xyz/valorant/v3/matches/'.rawurlencode($region).'/'.rawurlencode($name).'/'.rawurlencode($tag).'?size=20';
    [$mCode,$mJson] = hget($mUrl, HENRIK_API_KEY);
} catch (Throwable $e) { respond(['ok'=>false,'error'=>'Match fetch: '.$e->getMessage()]); }

if ($debug) {
    $summary = [];
    foreach (($mJson['data']??[]) as $m) {
        $meta=$m['metadata']??[];
        $isNew=isset($meta['match_id']);
        $allP=$isNew?($m['players']??[]):($m['players']['all_players']??[]);
        $summary[]=[
            'schema'      =>$isNew?'new':'old',
            'match_id'    =>$meta['match_id']??$meta['matchid']??'?',
            'map'         =>is_array($meta['map']??null)?($meta['map']['name']??'?'):($meta['map']??'?'),
            'mode'        =>$meta['mode']??'?',
            'mode_id'     =>$meta['mode_id']??'?',
            'queue_raw'   =>$meta['queue']??'?',
            'queue_id'    =>is_array($meta['queue']??null)?($meta['queue']['id']??'?'):($meta['queue']??'?'),
            'player_count'=>count($allP),
            'team_field'  =>isset($allP[0]['team_id'])?'team_id':(isset($allP[0]['team'])?'team':'?'),
        ];
    }
    respond(['ok'=>true,'debug'=>true,'http'=>$mCode,'matches'=>$summary]);
}

if ($mCode!==200) respond(['ok'=>false,'error'=>'Henrik matches API: HTTP '.$mCode]);
$allMatches = is_array($mJson['data'])?$mJson['data']:[];

// 4. Seen match IDs
$seenSt=$pdo->prepare('SELECT match_id FROM matches WHERE player_id=?');
$seenSt->execute([$playerId]);
$seen=array_flip(array_column($seenSt->fetchAll(),'match_id'));

$streakBonus=unserialize(CP_STREAK_BONUS)?:[0,0,2,3,5];
$cpPerTier=defined('CP_PER_TIER')?(int)CP_PER_TIER:100;
$synced=$skipped=$found2v2=0;

foreach ($allMatches as $match) {
    $meta=$match['metadata']??[];
    $isNew=isset($meta['match_id']);
    $matchId=(string)($isNew?($meta['match_id']??''):($meta['matchid']??''));
    if (!$matchId||isset($seen[$matchId])) continue;

    $queueId='';
    if (is_array($meta['queue']??null)) $queueId=strtolower($meta['queue']['id']??'');
    else $queueId=strtolower($meta['mode_id']??$meta['queue']??'');
    $modeStr=strtolower($meta['mode']??'');

    if ($isNew) { $allP=$match['players']??[]; $tf='team_id'; }
    else        { $allP=$match['players']['all_players']??[]; $tf='team'; }

    $isSkirmish=strpos($queueId,'skirmish')!==false||strpos($modeStr,'skirmish')!==false;
    $has4=is_array($allP)&&count($allP)===4;
    if (!$isSkirmish&&!$has4) { $skipped++; continue; }
    $found2v2++;

    $me=null;
    foreach ($allP as $pl) {
        if ((string)($pl['puuid']??'')===$puuid){$me=$pl;break;}
    }
    if (!$me) {
        foreach ($allP as $pl) {
            if (strtolower($pl['name']??'')==strtolower($name)&&strtolower($pl['tag']??'')==strtolower($tag))
                {$me=$pl;break;}
        }
    }
    if (!$me) continue;

    $myTeam=strtolower((string)($me[$tf]??'red'));
    $oppTeam=$myTeam==='red'?'blue':'red';
    $won=(bool)pick($match,"teams.{$myTeam}.has_won",false);
    $rw=(int)pick($match,"teams.{$myTeam}.rounds_won",0);
    $rl=(int)pick($match,"teams.{$oppTeam}.rounds_won",0);

    $kills=(int)pick($me,'stats.kills',0);
    $deaths=(int)pick($me,'stats.deaths',0);
    $ass=(int)pick($me,'stats.assists',0);
    $hs=(int)pick($me,'stats.headshots',0);
    $bs=(int)pick($me,'stats.bodyshots',0);
    $ls=(int)pick($me,'stats.legshots',0);
    $kda=round(($kills+$ass*0.5)/max(1,$deaths),2);

    $partner=null;
    foreach ($allP as $pl) {
        if (strtolower($pl[$tf]??'')===$myTeam&&($pl['puuid']??'')!==$puuid){$partner=$pl;break;}
    }
    $partnerPuuid=$partner?(string)($partner['puuid']??''):'';
    $partnerName=$partner?($partner['name']??'').'#'.($partner['tag']??''):'—';

    $mapName=is_array($meta['map']??null)?($meta['map']['name']??'Unknown'):($meta['map']??'Unknown');
    $startedAt=(string)($meta['started_at']??$meta['game_start_patched']??'');
    $playedAt=$startedAt?gmdate('Y-m-d H:i:s',strtotime($startedAt)):null;

    if ($won) {
        $cp=(int)CP_WIN_BASE;
        if ($kda>=3.5) $cp+=(int)CP_WIN_KDA_HIGH;
        elseif ($kda>=2.0) $cp+=(int)CP_WIN_KDA_LOW;
        $diff=$rw-$rl;
        if ($rl===0) $cp+=(int)CP_WIN_FLAWLESS;
        elseif ($diff>=6) $cp+=(int)CP_WIN_DOMINANT;
        $win_streak=min(10,$win_streak+1);
        $idx=min(count($streakBonus)-1,$win_streak);
        $cp+=(int)($streakBonus[$idx]??0);
        $wins++;
    } else {
        $cp=(int)CP_LOSS_BASE;
        if ($kda>=3.0) $cp+=(int)CP_LOSS_MITIGATION;
        $win_streak=0; $losses++;
    }
    $cp=max(-15,min(25,$cp));
    $total_cp=max(0,$total_cp+$cp);

    try {
        $pdo->prepare('INSERT IGNORE INTO matches
            (player_id,match_id,map_name,queue_id,partner_puuid,partner_name,
             won,kills,deaths,assists,headshots,bodyshots,legshots,
             rounds_won,rounds_lost,cp_delta,kda_ratio,played_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$playerId,$matchId,$mapName,$queueId,$partnerPuuid,$partnerName,
                $won?1:0,$kills,$deaths,$ass,$hs,$bs,$ls,$rw,$rl,$cp,$kda,$playedAt]);
        $synced++; $seen[$matchId]=1;
    } catch (Throwable $e) { error_log("[dual2v2] insert $matchId: ".$e->getMessage()); }
}

$cntSt=$pdo->prepare('SELECT COUNT(*) FROM matches WHERE player_id=?');
$cntSt->execute([$playerId]);
$totalInDb=(int)$cntSt->fetchColumn();
if (!$placement&&$totalInDb>=5) $placement=1;

$tier=max(0,min(8,(int)floor($total_cp/$cpPerTier)));
$cpInTier=$placement?($total_cp%$cpPerTier):0;

$pdo->prepare('UPDATE players SET total_cp=?,cp_in_tier=?,tier=?,wins=?,losses=?,win_streak=?,placement_done=?,last_sync=NOW() WHERE id=?')
    ->execute([$total_cp,$cpInTier,$tier,$wins,$losses,$win_streak,$placement,$playerId]);

$histSt=$pdo->prepare('SELECT match_id,map_name,queue_id,partner_puuid,partner_name,won,
    kills,deaths,assists,headshots,bodyshots,legshots,rounds_won,rounds_lost,cp_delta,kda_ratio,played_at
    FROM matches WHERE player_id=? ORDER BY played_at DESC LIMIT 50');
$histSt->execute([$playerId]);

// Determine claim state for logged-in user
$claimState = 'none';
$u = current_user();
if ($u) $claimState = claim_state((int)$u['id'], $playerId);

// Reload fresh player row for customisation fields
$freshSt=$pdo->prepare('SELECT nickname,country_flag,hide_rank,hide_stats,vanity_slug,claimed_by FROM players WHERE id=? LIMIT 1');
$freshSt->execute([$playerId]);
$fresh=$freshSt->fetch();

respond([
    'ok'            => true,
    'player'        => [
        'id'             => $playerId,
        'name'           => $name,
        'tag'            => $tag,
        'region'         => $region,
        'card_url'       => $cardUrl,
        'total_cp'       => $total_cp,
        'cp_in_tier'     => $cpInTier,
        'tier'           => $tier,
        'wins'           => $wins,
        'losses'         => $losses,
        'win_streak'     => $win_streak,
        'placement_done' => $placement,
        'last_sync'      => gmdate('Y-m-d H:i:s'),
        'vanity_slug'    => $fresh['vanity_slug']??'',
        'nickname'       => $fresh['nickname']??'',
        'country_flag'   => $fresh['country_flag']??'',
        'hide_rank'      => (int)($fresh['hide_rank']??0),
        'hide_stats'     => (int)($fresh['hide_stats']??0),
        'is_claimed'     => !empty($fresh['claimed_by']),
    ],
    'claim_state'   => $claimState,  // 'none'|'pending'|'approved'|'denied'|'claimed_by_other'
    'matches'       => $histSt->fetchAll(),
    'synced'        => $synced,
    'skipped_non2v2'=> $skipped,
    'total_2v2_found'=> $found2v2,
    'total_in_db'   => $totalInDb,
]);